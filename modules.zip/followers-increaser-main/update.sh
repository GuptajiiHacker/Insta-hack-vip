cd .. 
rm -rf followers-increaser
git clone https://github.com/security-softwares/followers-increaser/
cd followers-increaser
bash increaser.sh
